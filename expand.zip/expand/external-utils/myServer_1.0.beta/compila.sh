make clean
make 
cp *.exe /home/lmsan/bin/
