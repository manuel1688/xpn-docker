

 #ifndef TRACE_TAGS_H
 #define TRACE_TAGS_H

   /* ... Include / Inclusion ........................................... */

      #include "all_system.h"


 #ifdef  __cplusplus
    extern "C" {
 #endif


   /* ... Consts / Constantes ........................................... */

      #define  SPOT __LINE__,__FILE__,getpid(),0


   /* ................................................................... */

 #ifdef  __cplusplus
    }
 #endif


 #endif

