#ifndef _GSOAP_LIB_H_
#define _GSOAP_LIB_H_

#include "nfi_gsoap.h"

#endif
