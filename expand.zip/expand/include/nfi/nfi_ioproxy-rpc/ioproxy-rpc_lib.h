#ifndef _IOPROXY_RPC_LIB_H_
#define _IOPROXY_RPC_LIB_H_

#include "nfi_ioproxy-rpc.h"

#endif
