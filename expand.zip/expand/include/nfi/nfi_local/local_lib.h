#ifndef _LOCAL_LIB_H_
#define _LOCAL_LIB_H_

#include "nfi_local.h"

#endif
