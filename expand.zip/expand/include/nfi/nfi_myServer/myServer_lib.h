#ifndef _MYSERVER_LIB_H_
#define _MYSERVER_LIB_H_

#include "nfi_myServer.h"

#endif
