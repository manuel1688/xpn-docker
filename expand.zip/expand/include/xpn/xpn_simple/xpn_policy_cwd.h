#ifndef _XPN_POLICY_CWD_H
#define _XPN_POLICY_CWD_H

#include "all_system.h"
#include "xpn_cwd.h"


 #ifdef  __cplusplus
    extern "C" {
 #endif

int XpnGetAbsolutePath(const char *path, char *path_part);


 #ifdef  __cplusplus
     }
 #endif


#endif

