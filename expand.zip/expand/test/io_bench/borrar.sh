#!/bin/bash
rm -f /export/temp/pato??/bbergua/*
