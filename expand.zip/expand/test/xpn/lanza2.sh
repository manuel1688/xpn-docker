rsh pato13 /export/home/pato11-1/proyectos/xpn/expand-2.0/test/xpn/prueba/lanza1.sh
rsh pato23 /export/home/pato11-1/proyectos/xpn/expand-2.0/test/xpn/prueba/lanza1.sh
rsh pato33 /export/home/pato11-1/proyectos/xpn/expand-2.0/test/xpn/prueba/lanza1.sh
rsh pato43 /export/home/pato11-1/proyectos/xpn/expand-2.0/test/xpn/prueba/lanza1.sh
rsh pato53 /export/home/pato11-1/proyectos/xpn/expand-2.0/test/xpn/prueba/lanza1.sh
rsh pato63 /export/home/pato11-1/proyectos/xpn/expand-2.0/test/xpn/prueba/lanza1.sh
rsh pato73 /export/home/pato11-1/proyectos/xpn/expand-2.0/test/xpn/prueba/lanza1.sh
rsh pato83 /export/home/pato11-1/proyectos/xpn/expand-2.0/test/xpn/prueba/lanza1.sh
